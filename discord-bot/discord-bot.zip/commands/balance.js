import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { getDbConnection } from '../utils/database.js';

export default {
  data: new SlashCommandBuilder()
    .setName('balance')
    .setDescription('Проверить баланс аккаунта'),
  
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    try {
      const db = await getDbConnection();
      const discordId = interaction.user.id;

      // Получаем пользователя
      const [users] = await db.query(
        'SELECT id, username, balance FROM users WHERE discordId = ?',
        [discordId]
      );

      if (users.length === 0) {
        const embed = new EmbedBuilder()
          .setColor('#ff0000')
          .setTitle('❌ Аккаунт не привязан')
          .setDescription(
            'Ваш Discord аккаунт не привязан к Avelon.\n' +
            'Используйте команду `/link` для привязки аккаунта.'
          )
          .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
        return;
      }

      const user = users[0];

      const embed = new EmbedBuilder()
        .setColor('#0099ff')
        .setTitle('💰 Баланс аккаунта')
        .addFields(
          { name: 'Пользователь', value: user.username, inline: true },
          { name: 'Баланс', value: `${user.balance.toFixed(2)} ₽`, inline: true }
        )
        .setThumbnail(interaction.user.displayAvatarURL())
        .setTimestamp()
        .setFooter({ text: 'Avelon Billing System' });

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error('Error checking balance:', error);

      const embed = new EmbedBuilder()
        .setColor('#ff0000')
        .setTitle('❌ Ошибка')
        .setDescription('Произошла ошибка при получении баланса.')
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    }
  },
};
